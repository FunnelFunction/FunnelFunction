
export interface Business {
    name: string;
    address: string;
    phone: string;
    website: string;
}

export interface Source {
    uri: string;
    title: string;
}

export interface ReconData {
    totalPages: number;
    resultsPerPage: number;
    summary: string;
    searchUrl: string;
}

export interface ReconState {
    loading: boolean;
    error: string | null;
    data: ReconData | null;
}

export interface ScrapeState {
    loading: boolean;
    error: string | null;
    results: Business[];
}

export type ContactMethod = 'address' | 'phone' | 'website' | 'emails';

export interface ContactDetail {
    id: string;
    value: string;
}

export interface BusinessDetails {
    name: string;
    address: ContactDetail[];
    phone: ContactDetail[];
    website: ContactDetail[];
    emails: ContactDetail[];
}

export interface ProfileData {
    name: string;
    company: string;
    title: string;
    email: string;
    phone: string;
    businessDescription: string;
}

export interface BoardState {
    city: string;
    categoryPhases: { [key: string]: number | null };
    reconData: { [key: string]: ReconState };
    scrapedResults: { [key: string]: ScrapeState };
    scrapedBusinessDetails: { [key: string]: BusinessDetails };
    contactDetailPhases: { [key: string]: number | null };
    emailTemplates: { [key: string]: string };
    emailScrapeState: { [key: string]: { loading: boolean; error: string | null } };
    bulkEmailScrapeState: { [key: string]: { loading: boolean; error: string | null } };
    expandedCategories: Set<string>;
    expandedBusinesses: { [key: string]: Set<string> };
    gifBaseUrl: string;
}
