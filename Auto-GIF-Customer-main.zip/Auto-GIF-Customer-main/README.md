
# Armstrong Strategy Board & Automated Marketing Engine

> **"I am the readme."**
> *This document details the architecture, build process, and strategic purpose of the Armstrong application.*

## 🚀 The Purpose: The "Self-GIF Making Machine"

This application is not just a CRM; it is a **Lead Generation and Automated Marketing Machine**. 

The core philosophy behind this build is **Automated Pre-Construction**. Instead of finding a lead and *then* thinking about how to pitch them, this app:
1.  **Scrapes** the web for business targets.
2.  **Analyzes** their market position.
3.  **Extracts** their contact details (including deep-diving for emails).
4.  **Pre-constructs** a custom marketing asset (a dynamic GIF) specifically for that business before you even say "hello".

The goal is to walk into a sales pitch holding a finished product (the GIF) that features *their* company name, *their* services, and *their* branding, generated instantly from the data we scraped.

---

## ⚙️ Configuration & Setup (Template Instructions)

This project is a template. Before running, you **MUST** configure your external service keys.

### 1. Firebase Config
Open `firebase.ts` and replace the placeholder values with your actual Firebase project details:
*   `apiKey`
*   `authDomain`
*   `projectId`
*   etc.

### 2. Google Gemini API Key
The application requires a Google Gemini API Key to perform the AI scraping and analysis.
*   Ensure your build environment (or local `.env` file if using Vite locally) has `API_KEY` defined.
*   The code accesses this via `process.env.API_KEY`.

### 3. GIF Generation Service
This app relies on an external microservice to generate the GIFs.
*   Open `App.tsx` and update the `gifBaseUrl` property in the `defaultBoardState` object to point to your hosted GIF service.
*   You can also configure this dynamically inside the app via the **Category Settings** dropdown on the Strategy Board.

---

## 🛠️ How We Built It

This application was engineered using a modern, serverless stack relying heavily on Generative AI for data processing rather than traditional DOM parsing.

### The Tech Stack
*   **Frontend Core**: React 19 (TypeScript) for a type-safe, reactive UI.
*   **AI Engine**: **Google Gemini 2.5 Flash** via the `@google/genai` SDK.
    *   *Why?* Traditional scrapers break when DOM structures change. We use Gemini with **Google Search Grounding** to "read" the web like a human and return structured JSON data, making it immune to layout changes.
*   **Backend / Auth**: **Firebase v10**.
    *   *Authentication*: Handles Email/Password flows, Verification, and Profile Management.
    *   *Storage*: Host user profile photos.
*   **Marketing Engine**: Integration with an external **Dynamic GIF API** to generate programmatic visual assets.
*   **Styling**: Custom CSS variable system implementing a "Glassmorphism" aesthetic (blurred backdrops, translucent panes) for a modern, high-end feel.

---

## 🧠 The Architecture & Logic

### 1. The Data Pipeline (AI-Powered Scraping)
Unlike standard scraping, we don't regex HTML. We prompt the AI:
1.  **Reconnaissance**: We ask Gemini to search a specific City + Category and analyze the "Market Size" (Total pages, density).
2.  **Entity Extraction**: We ask Gemini to find businesses and output a **raw JSON object** containing `name`, `address`, `phone`, and `website`.
3.  **Deep Email Scrape**: When a website is found, we trigger a secondary AI agent to visit that specific URL, look for "Contact", "About", or "Staff" pages, and extract email addresses into a clean array.

### 2. The State Management
The app uses a monolithic state object (`boardState`) synced to `localStorage`. This ensures that if the browser closes, your leads, scraped data, and phase progress are preserved.
*   **Phases**: Every lead tracks 4 phases: Analysis, Initial Contact, Follow-up, Closed.
*   **Expanded Sets**: We track which categories and businesses are expanded to maintain UI state.

### 3. The "GIF Strategy" Integration
The app dynamically constructs URLs for the GIF service based on the scraped data.
*   *Input*: Scraped Business Name ("Joe's Pizza") + Scraped Category ("Restaurant").
*   *Process*: The app encodes these into a URL: `/marketing.gif?company=Joe's%20Pizza&services=Restaurant`.
*   *Output*: A visual asset created instantly to be attached to the outreach email.

---

## 📖 How To Use It (The Workflow)

### Step 1: Authentication & Profile
1.  **Login/Signup**: Create an account via Firebase.
2.  **Profile Setup**: Click your avatar. Fill in your details (Name, Company, Title).
    *   *Why?* These details are auto-injected into your email templates later.

### Step 2: The Strategy Board (The War Room)
This is the main interface. It lists business categories (imported from `google-business-categories.json`) against a 4-phase grid.

1.  **Select a City**: Enter your target market (e.g., "Austin, TX").
2.  **Phase 1 (Market Analysis)**: 
    *   Click the radio button in the **Phase 1** column for a category (e.g., "Accountant").
    *   **What happens**: The AI performs a "Recon" search to tell you how many accountants are in Austin and provides a summary.
3.  **The Scrape**:
    *   Open the category accordion. Click **"Scrape"**.
    *   **What happens**: The AI finds actual businesses. A list appears below the category.
4.  **The Deep Dive**:
    *   Click a specific business to expand it.
    *   You will see fields for Address, Phone, Website, and Emails.
    *   **Action**: If emails are missing, click **"Scrape URL for Emails"**. The AI goes to their site and hunts for contact info.

### Step 3: The Setup (The GIF)
1.  Next to the business name, click the **"GIF"** button.
2.  **What happens**: The system takes the business name and category you just found, generates a custom marketing GIF, and displays it.
3.  **The Play**: Copy this GIF URL. You will use this in your cold email to show you've already done work for them.

### Step 4: Outreach (Phase 2 & 3)
1.  Click the **Template Icon** (next to the category name) to write your email script for this industry.
2.  Use placeholders like `{{customer_name}}` and `{{admin_name}}`.
3.  In the business row, move the phase bubble to **Phase 2 (Initial Contact)**.
4.  **Automation**: If you click the "Emails" phase bubble, the app simulates opening your mail client with the subject and body pre-filled with the scraped data and your template.

---

## 🔑 Key Features Summary

*   **Search Grounding**: Uses real-time Google Search results, not stale training data.
*   **Forensic Logging**: Console logs are prefixed with `[FORENSIC LOG]` to trace exactly where AI scraping might fail (useful for debugging).
*   **Glass UI**: A distinct visual style that separates data layers using translucency.
*   **Bulk Actions**: "Scrape All Emails" button triggers sequential AI agents for every business in a category.

---

## ⚠️ Forensic Notes for Developers

*   **TypeScript Interfaces**: Strict typing (`Business`, `ReconData`, `ProfileData`) is enforced to handle the unpredictable nature of AI JSON responses.
*   **JSON Parsing**: The AI output is sanitized (`replace(/^```json|```$/g, '')`) before parsing because LLMs sometimes wrap output in Markdown blocks.
*   **Race Conditions**: The `useEffect` hooks handle data fetching, but Firebase Auth is asynchronous; the loader state manages this transition.

**This is the machine. It finds them, it researches them, and it builds the pitch for them.**
