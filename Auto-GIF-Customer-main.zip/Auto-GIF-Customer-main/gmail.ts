// Gmail API utility for sending emails

export interface EmailPayload {
    to: string;
    from: string;
    subject: string;
    body: string;
}

/**
 * Sends an email using the Gmail API
 * @param accessToken - The Google OAuth access token (provider_token from Supabase session)
 * @param email - The email payload containing to, from, subject, and body
 * @returns Promise with success status and message
 */
export async function sendGmailEmail(
    accessToken: string,
    email: EmailPayload
): Promise<{ success: boolean; message: string; error?: string }> {
    try {
        // Construct the email in RFC 2822 format
        const emailLines = [
            `From: ${email.from}`,
            `To: ${email.to}`,
            `Subject: ${email.subject}`,
            'Content-Type: text/plain; charset=utf-8',
            'MIME-Version: 1.0',
            '',
            email.body,
        ];

        const rawEmail = emailLines.join('\r\n');

        // Base64 URL encode the email (Gmail API requirement)
        const encodedEmail = btoa(unescape(encodeURIComponent(rawEmail)))
            .replace(/\+/g, '-')
            .replace(/\//g, '_')
            .replace(/=+$/, '');

        // Send via Gmail API
        const response = await fetch(
            'https://gmail.googleapis.com/gmail/v1/users/me/messages/send',
            {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${accessToken}`,
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    raw: encodedEmail,
                }),
            }
        );

        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            console.error('[sendGmailEmail] API error:', errorData);

            if (response.status === 401) {
                return {
                    success: false,
                    message: 'Authentication expired. Please sign in with Google again.',
                    error: 'TOKEN_EXPIRED',
                };
            }

            if (response.status === 403) {
                return {
                    success: false,
                    message: 'Gmail permission denied. Please sign in with Google and grant email access.',
                    error: 'PERMISSION_DENIED',
                };
            }

            return {
                success: false,
                message: `Failed to send email: ${errorData.error?.message || 'Unknown error'}`,
                error: 'API_ERROR',
            };
        }

        const result = await response.json();
        console.log('[sendGmailEmail] Email sent successfully. Message ID:', result.id);

        return {
            success: true,
            message: `Email sent successfully to ${email.to}`,
        };

    } catch (error) {
        console.error('[sendGmailEmail] Exception:', error);
        return {
            success: false,
            message: 'Failed to send email. Please check your connection and try again.',
            error: 'NETWORK_ERROR',
        };
    }
}
