import React, { useState } from 'react';
import { supabase } from '../supabase';
import { AuthError } from '@supabase/supabase-js';

const AuthComponent = () => {
    const [view, setView] = useState<'login' | 'signup' | 'verifyEmail' | 'forgotPassword'>('login');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [repeatPassword, setRepeatPassword] = useState('');
    const [name, setName] = useState('');
    const [profileFile, setProfileFile] = useState<File | null>(null);
    const [profilePreview, setProfilePreview] = useState<string | null>(null);
    const [error, setError] = useState('');
    const [message, setMessage] = useState('');
    const [loading, setLoading] = useState(false);

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            const file = e.target.files[0];
            setProfileFile(file);
            setProfilePreview(URL.createObjectURL(file));
        }
    };

    const handleAuthAction = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);
        setError('');
        setMessage('');

        if (view === 'login') {
            try {
                const { data, error: signInError } = await supabase.auth.signInWithPassword({
                    email,
                    password,
                });

                if (signInError) {
                    if (signInError.message.includes('Invalid login credentials')) {
                        setError('Incorrect email or password. Please try again.');
                    } else if (signInError.message.includes('Email not confirmed')) {
                        setMessage(`Please check your inbox to verify your account before logging in.`);
                        setView('verifyEmail');
                    } else {
                        setError('Failed to sign in. Please try again later.');
                    }
                    console.error("Sign in error:", signInError);
                }
            } catch (err) {
                const error = err as AuthError;
                setError('Failed to sign in. Please try again later.');
                console.error("Sign in error:", error);
            }
        } else { // Signup
            if (password !== repeatPassword) {
                setError('Passwords do not match.');
                setLoading(false);
                return;
            }
            try {
                const { data, error: signUpError } = await supabase.auth.signUp({
                    email,
                    password,
                    options: {
                        data: {
                            display_name: name,
                        }
                    }
                });

                if (signUpError) {
                    if (signUpError.message.includes('already registered')) {
                        setError('User already exists. Sign in instead?');
                    } else {
                        setError('Failed to create account. Please try again.');
                    }
                    console.error("Sign up error:", signUpError);
                    setLoading(false);
                    return;
                }

                // Upload profile photo if provided
                if (profileFile && data.user) {
                    const fileExt = profileFile.name.split('.').pop();
                    const filePath = `${data.user.id}/avatar.${fileExt}`;

                    const { error: uploadError } = await supabase.storage
                        .from('avatars')
                        .upload(filePath, profileFile, { upsert: true });

                    if (!uploadError) {
                        const { data: urlData } = supabase.storage
                            .from('avatars')
                            .getPublicUrl(filePath);

                        await supabase.auth.updateUser({
                            data: { avatar_url: urlData.publicUrl }
                        });
                    }
                }

                setMessage(`We have sent you a verification email to ${email}. Please check your inbox and verify your account to log in.`);
                setView('verifyEmail');

            } catch (err) {
                const error = err as AuthError;
                setError('Failed to create account. Please try again.');
                console.error("Sign up error:", error);
            }
        }
        setLoading(false);
    };

    const handlePasswordReset = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);
        setError('');
        setMessage('');
        try {
            const { error: resetError } = await supabase.auth.resetPasswordForEmail(email, {
                redirectTo: `${window.location.origin}/reset-password`,
            });

            if (resetError) {
                setError('Failed to send reset link. Please try again.');
                console.error("Password reset error:", resetError);
            } else {
                setMessage(`We sent you a password reset link to ${email}. Check your inbox (and spam folder) to reset your password.`);
                setView('verifyEmail');
            }
        } catch (err) {
            const error = err as AuthError;
            setError('Failed to send reset link. Please try again.');
            console.error("Password reset error:", error);
        }
        setLoading(false);
    };

    const switchView = (newView: 'login' | 'signup') => {
        setView(newView);
        setError('');
        setMessage('');
    };

    const handleGoogleSignIn = async () => {
        setLoading(true);
        setError('');
        try {
            const { error: googleError } = await supabase.auth.signInWithOAuth({
                provider: 'google',
                options: {
                    scopes: 'https://www.googleapis.com/auth/gmail.send',
                    redirectTo: 'https://auto-gif-customer.onrender.com',
                }
            });
            if (googleError) {
                setError('Failed to sign in with Google. Please try again.');
                console.error("Google sign in error:", googleError);
            }
        } catch (err) {
            setError('Failed to sign in with Google. Please try again.');
            console.error("Google sign in error:", err);
        }
        setLoading(false);
    };

    const renderContent = () => {
        switch (view) {
            case 'verifyEmail':
                return (
                    <>
                        <h2>Check Your Inbox</h2>
                        <p>{message}</p>
                        <button onClick={() => setView('login')} className="chrome-button" style={{width: '100%', justifyContent: 'center'}}>Back to Login</button>
                    </>
                );
            case 'forgotPassword':
                return (
                     <>
                        <h2>Reset Password</h2>
                        <p>Enter your email address and we'll send you a link to reset your password.</p>
                        <form className="auth-form" onSubmit={handlePasswordReset}>
                             <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="Email Address" required />
                             {error && <p className="error" style={{ margin: 0 }}>{error}</p>}
                             <button type="submit" disabled={loading}>{loading ? 'Sending...' : 'Get Reset Link'}</button>
                        </form>
                        <div className="auth-toggle">
                            Remember your password?
                            <button onClick={() => setView('login')}>Sign In</button>
                        </div>
                    </>
                );
            case 'login':
            case 'signup':
                return (
                     <>
                        <h2>{view === 'login' ? 'Welcome Back' : 'Create Your Account'}</h2>
                        <form className="auth-form" onSubmit={handleAuthAction}>
                            {view === 'signup' && (
                                <>
                                    <div className="profile-photo-uploader">
                                        <label htmlFor="profilePhotoInput" className="profile-photo-preview" style={{backgroundImage: profilePreview ? `url(${profilePreview})` : 'none'}}>
                                            {!profilePreview && (
                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                                            )}
                                        </label>
                                        <input id="profilePhotoInput" type="file" accept="image/*" onChange={handleFileChange} />
                                        <span>Upload Profile Photo</span>
                                    </div>
                                    <input type="text" value={name} onChange={e => setName(e.target.value)} placeholder="Your Name" required />
                                </>
                            )}
                            <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="Email Address" required />
                            <input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Password" required />
                             {view === 'login' && (
                                <div className="forgot-password">
                                    <button type="button" onClick={() => setView('forgotPassword')}>Forgot Password?</button>
                                </div>
                            )}
                            {view === 'signup' && (
                                <input type="password" value={repeatPassword} onChange={e => setRepeatPassword(e.target.value)} placeholder="Repeat Password" required />
                            )}

                            {error && <p className="error" style={{ margin: 0 }}>{error}</p>}

                            <button type="submit" disabled={loading}>
                                {loading ? 'Processing...' : (view === 'login' ? 'Sign In' : 'Create Account')}
                            </button>
                        </form>
                        <div className="auth-toggle">
                            {view === 'login' ? "Don't have an account?" : "Already have an account?"}
                            <button onClick={() => switchView(view === 'login' ? 'signup' : 'login')}>
                                {view === 'login' ? 'Sign Up' : 'Sign In'}
                            </button>
                        </div>
                    </>
                );
        }
    }

    return (
        <div className="auth-container">
            <div className="auth-form-wrapper glass-pane">
                <button
                    className="google-sign-in-icon"
                    onClick={handleGoogleSignIn}
                    disabled={loading}
                    title="Sign in with Google"
                    type="button"
                >
                    <svg viewBox="0 0 24 24" width="20" height="20">
                        <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                        <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                        <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                        <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                    </svg>
                </button>
                {renderContent()}
            </div>
        </div>
    );
};

export default AuthComponent;
