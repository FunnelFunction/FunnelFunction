
import React, { useState, useEffect, useRef, Fragment } from 'react';
import { GoogleGenAI } from '@google/genai';
import { Business, ContactDetail, ContactMethod, ProfileData, BusinessDetails } from '../types';
import EmailTemplateModal from './modals/EmailTemplateModal';
import GifModal from './modals/GifModal';
import { sendGmailEmail } from '../gmail';

// --- DEFAULTS & HELPERS --- //
const createDefaultTemplate = (category: string): string => {
    return `Subject: Partnership Opportunity for ${category} businesses

Hello {{customer_name}},

My name is {{admin_name}}, and I'm the {{admin_title}} at {{admin_company}}. Our company specializes in {{admin_businessDescription}}.

I came across your work in the ${category} industry and was very impressed. We believe our services could be a significant asset to a company like yours.

Here's a personalized preview of what we can create for you:
{{gif_url}}

Would you be open to a brief conversation next week to explore how we can help {{customer_name}} achieve its goals?

Best regards,

{{admin_name}}
{{admin_title}}
{{admin_company}}
{{admin_phone}}
{{admin_email}}`;
};

// Helper to generate GIF URL for a business
const generateGifUrl = (baseUrl: string, businessName: string, category: string, websiteUrl: string): string => {
    const company = encodeURIComponent(businessName);
    const services = encodeURIComponent(category);
    const website = encodeURIComponent(websiteUrl || '');
    const seed = encodeURIComponent(businessName);
    return `${baseUrl}/marketing.gif?count=6&random=true&seed=${seed}&company=${company}&services=${services}&url=${website}&font=tech&geometry=sharp`;
};

const StrategyBoard = ({ appProfileData, boardState, setBoardState, providerToken }: { appProfileData: ProfileData, boardState: any, setBoardState: React.Dispatch<React.SetStateAction<any>>, providerToken?: string }) => {
    const [categories, setCategories] = useState<string[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [isTemplateModalOpen, setIsTemplateModalOpen] = useState(false);
    const [editingTemplateForCategory, setEditingTemplateForCategory] = useState<string | null>(null);
    const [isCategoryToolkitOpen, setIsCategoryToolkitOpen] = useState(false);
    const [emailSending, setEmailSending] = useState<{ [key: string]: boolean }>({});
    const [gifModalUrl, setGifModalUrl] = useState<string | null>(null);
    const toolkitRef = useRef<HTMLTableHeaderCellElement>(null);

    useEffect(() => {
        fetch('google-business-categories.json')
            .then(res => res.json())
            .then((data: any) => setCategories(data as string[]))
            .catch(err => {
                 console.error("[useEffect] FORENSIC LOG: Failed to fetch business categories. Error:", err);
                 setError("Could not load business categories.");
            })
            .finally(() => setLoading(false));
    }, []);
    
    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (toolkitRef.current && !toolkitRef.current.contains(event.target as Node)) {
                setIsCategoryToolkitOpen(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, []);

    const handleOpenTemplateModal = (category: string) => {
        setEditingTemplateForCategory(category);
        setIsTemplateModalOpen(true);
    };

    const handleSaveTemplate = (category: string, newTemplate: string) => {
        setBoardState((prev: any) => ({
            ...prev,
            emailTemplates: { ...prev.emailTemplates, [category]: newTemplate, },
        }));
    };

    const handleCategoryPhaseChange = async (category: string, phase: number) => {
        if (phase !== 1) return;

        const isActivating = boardState.categoryPhases[category] !== 1;
        
        if (isActivating) {
            setBoardState((prev: any) => {
                const newExpandedCategories = new Set(prev.expandedCategories);
                newExpandedCategories.add(category);
                return {
                    ...prev,
                    categoryPhases: { ...prev.categoryPhases, [category]: 1 },
                    expandedCategories: newExpandedCategories,
                    reconData: { ...prev.reconData, [category]: { loading: true, error: null, data: null } }
                };
            });

            try {
                const ai = new GoogleGenAI({ apiKey: import.meta.env.VITE_GEMINI_API_KEY });
                const prompt = `For the business category "${category}" in "${boardState.city}", perform a search and analyze the results to determine the market size. Respond with ONLY a raw JSON object (no markdown) with the following keys: "totalPages" (a number representing the total number of result pages), "resultsPerPage" (a number representing the typical number of results on a page), "summary" (a brief string explaining the findings), and "searchUrl" (a string containing the full URL to the Google search results page).`;
                
                const response = await ai.models.generateContent({
                    model: "gemini-2.5-flash", contents: prompt, config: { tools: [{ googleSearch: {} }] }
                });
                
                let jsonText = (response.text || '').trim().replace(/^```json|```$/g, '').trim();
                const jsonResponse = JSON.parse(jsonText);
                setBoardState((prev: any) => ({ ...prev, reconData: { ...prev.reconData, [category]: { loading: false, error: null, data: jsonResponse } } }));

            } catch (e) {
                console.error(`[handleCategoryPhaseChange] FORENSIC LOG: Reconnaissance search failed for category "${category}". Error:`, e);
                setBoardState((prev: any) => ({ ...prev, reconData: { ...prev.reconData, [category]: { loading: false, error: "Failed to get market insights.", data: null } } }));
            }
        } else {
            setBoardState((prev: any) => ({ ...prev, categoryPhases: { ...prev.categoryPhases, [category]: null } }));
        }
    };
    
    const handleAddContactDetail = (businessIdentifier: string, method: ContactMethod) => {
        setBoardState((prev: any) => {
            const currentDetails = prev.scrapedBusinessDetails[businessIdentifier];
            if (!currentDetails) return prev;

            const newDetail: ContactDetail = { id: `${businessIdentifier}-${method}-${Date.now()}`, value: '' };
            
            let existingDetails = currentDetails[method];
            if (method === 'emails' && existingDetails.some((d: any) => d.value.startsWith('SCRAPE_URL_PLACEHOLDER'))) {
                existingDetails = []; 
            }

            return {
                ...prev,
                scrapedBusinessDetails: {
                    ...prev.scrapedBusinessDetails,
                    [businessIdentifier]: { ...currentDetails, [method]: [...existingDetails, newDetail] }
                }
            };
        });
    };

    const handleContactDetailValueChange = (businessIdentifier: string, method: ContactMethod, id: string, newValue: string) => {
        setBoardState((prev: any) => {
            const currentDetails = prev.scrapedBusinessDetails[businessIdentifier];
            if (!currentDetails) return prev;

            const updatedMethodDetails = currentDetails[method].map((detail: any) =>
                detail.id === id ? { ...detail, value: newValue } : detail
            );

            return {
                ...prev,
                scrapedBusinessDetails: { ...prev.scrapedBusinessDetails, [businessIdentifier]: { ...currentDetails, [method]: updatedMethodDetails } }
            };
        });
    };
    
    const handleContactDetailPhaseChange = async (detail: ContactDetail, phase: number, businessDetails: BusinessDetails, category: string) => {
        if (phase < 2) return;
        const currentPhase = boardState.contactDetailPhases[detail.id];
        const newPhase = currentPhase === phase ? null : phase;
        setBoardState((prev: any) => ({ ...prev, contactDetailPhases: { ...prev.contactDetailPhases, [detail.id]: newPhase } }));

        if (newPhase === 2 && detail.id.includes('-emails-')) {
            const templateContent = boardState.emailTemplates[category] || createDefaultTemplate(category);

            // Generate the GIF URL for this business
            const gifUrl = generateGifUrl(
                boardState.gifBaseUrl || 'https://render-dynamic-marketing-gif.onrender.com',
                businessDetails.name,
                category,
                businessDetails.website[0]?.value || ''
            );

            const replacePlaceholders = (text: string) => text
                .replace(/{{admin_name}}/g, appProfileData.name || '')
                .replace(/{{admin_company}}/g, appProfileData.company || '')
                .replace(/{{admin_title}}/g, appProfileData.title || '')
                .replace(/{{admin_email}}/g, appProfileData.email || '')
                .replace(/{{admin_phone}}/g, appProfileData.phone || '')
                .replace(/{{admin_businessDescription}}/g, appProfileData.businessDescription || '')
                .replace(/{{customer_name}}/g, businessDetails.name || '')
                .replace(/{{customer_address}}/g, businessDetails.address[0]?.value || '')
                .replace(/{{customer_phone}}/g, businessDetails.phone[0]?.value || '')
                .replace(/{{customer_website}}/g, businessDetails.website[0]?.value || '')
                .replace(/{{gif_url}}/g, gifUrl);

            let subject = `Inquiry for ${businessDetails.name}`;
            let body = templateContent;
            const subjectMatch = templateContent.match(/^Subject: (.*)/m);
            if (subjectMatch && subjectMatch[1]) {
                subject = subjectMatch[1].trim();
                body = templateContent.replace(/^Subject: (.*)\r?\n/m, '').trim();
            }

            const finalSubject = replacePlaceholders(subject);
            const finalBody = replacePlaceholders(body);

            // Check if we have a provider token for Gmail API
            if (!providerToken) {
                alert('To send emails, please sign in with Google using the G icon on the login page. This grants permission to send emails on your behalf.');
                // Reset the phase since we couldn't send
                setBoardState((prev: any) => ({ ...prev, contactDetailPhases: { ...prev.contactDetailPhases, [detail.id]: null } }));
                return;
            }

            // Send actual email via Gmail API
            setEmailSending(prev => ({ ...prev, [detail.id]: true }));

            const result = await sendGmailEmail(providerToken, {
                to: detail.value,
                from: appProfileData.email,
                subject: finalSubject,
                body: finalBody,
            });

            setEmailSending(prev => ({ ...prev, [detail.id]: false }));

            if (result.success) {
                alert(`Email sent successfully to ${detail.value}!`);
            } else {
                alert(`Failed to send email: ${result.message}`);
                // Reset the phase since email failed
                setBoardState((prev: any) => ({ ...prev, contactDetailPhases: { ...prev.contactDetailPhases, [detail.id]: null } }));
            }
        }
    };

    const handleCategoryToggle = (category: string) => {
        setBoardState((prev: any) => {
            const newExpanded = new Set(prev.expandedCategories);
            newExpanded.has(category) ? newExpanded.delete(category) : newExpanded.add(category);
            return { ...prev, expandedCategories: newExpanded };
        });
    };

    const handleBusinessToggle = (businessIdentifier: string, category: string) => {
        setBoardState((prev: any) => {
            const categorySet = new Set(prev.expandedBusinesses[category] || []);
            if(categorySet.has(businessIdentifier)){
                categorySet.delete(businessIdentifier);
            } else {
                categorySet.add(businessIdentifier);
            }
            return { ...prev, expandedBusinesses: { ...prev.expandedBusinesses, [category]: categorySet} };
        });
    }
    
    const fetchScrapedResults = async (category: string) => {
        setBoardState((prev: any) => ({ ...prev, scrapedResults: { ...prev.scrapedResults, [category]: { loading: true, error: null, results: [] } }}));
        try {
            const ai = new GoogleGenAI({ apiKey: import.meta.env.VITE_GEMINI_API_KEY });
            const prompt = `Perform a comprehensive search for all "${category}" businesses in "${boardState.city}". Find as many unique results as possible. Respond with ONLY a raw JSON object containing a single key "businesses". The value of "businesses" should be an array of objects. For each business object, you MUST include the following keys: "name", "address", "phone", and "website". It is critical that you find the correct information for each key. The "address" must be a physical street address. The "phone" must be a valid phone number. The "website" must be a valid URL starting with http or https. If a specific piece of information for a key (like "website") cannot be found for a business, you MUST return an empty string "" for that key's value. Do not mix data between fields. Do not output markdown, just the raw JSON object.`;

            const response = await ai.models.generateContent({ model: "gemini-2.5-flash", contents: prompt, config: { tools: [{ googleSearch: {} }] } });
            let jsonText = (response.text || '').trim().replace(/^```json|```$/g, '').trim();
            const jsonResponse = JSON.parse(jsonText);
            const businesses: Business[] = jsonResponse.businesses || [];
            
            setBoardState((prev: any) => {
                const newDetails: { [key: string]: BusinessDetails } = {};
                businesses.forEach((business, index) => {
                    const businessIdentifier = `${category}-${business.name.replace(/\s/g, '-')}-${index}`;
                    newDetails[businessIdentifier] = {
                        name: business.name,
                        address: [{ id: `${businessIdentifier}-address-0`, value: business.address || '' }],
                        phone: [{ id: `${businessIdentifier}-phone-0`, value: business.phone || '' }],
                        website: [{ id: `${businessIdentifier}-website-0`, value: business.website || '' }],
                        emails: [{ id: `${businessIdentifier}-emails-0`, value: `SCRAPE_URL_PLACEHOLDER_${businessIdentifier}` }],
                    };
                });
                return {
                    ...prev,
                    scrapedBusinessDetails: { ...prev.scrapedBusinessDetails, ...newDetails },
                    scrapedResults: { ...prev.scrapedResults, [category]: { loading: false, error: null, results: businesses } },
                }
            });
        } catch(e) {
             console.error(`[fetchScrapedResults] FORENSIC LOG: Scrape failed for category "${category}". Error:`, e);
             setBoardState((prev: any) => ({ ...prev, scrapedResults: { ...prev.scrapedResults, [category]: { loading: false, error: "Failed to scrape businesses.", results: [] } }}));
        }
    };

    const handleScrapeEmails = async (businessIdentifier: string, websiteUrl: string) => {
        if (!websiteUrl || websiteUrl.trim() === '') {
            setBoardState((prev: any) => {
                const details = prev.scrapedBusinessDetails[businessIdentifier];
                return { ...prev, scrapedBusinessDetails: { ...prev.scrapedBusinessDetails, [businessIdentifier]: { ...details, emails: [{ id: `${businessIdentifier}-emails-error`, value: 'No website URL available.' }] } } };
            });
            return;
        }
        setBoardState((prev: any) => ({ ...prev, emailScrapeState: { ...prev.emailScrapeState, [businessIdentifier]: { loading: true, error: null } } }));
        try {
            const ai = new GoogleGenAI({ apiKey: import.meta.env.VITE_GEMINI_API_KEY });
            const prompt = `Perform a comprehensive site-wide search of the website "${websiteUrl}" to find all publicly listed email addresses. Your search must be thorough. Prioritize searching on pages commonly containing contact information, such as 'Contact Us', 'About Us', 'Meet the Team', 'Staff Directory', and in the website's footer. Extract every unique email address you find. Respond with ONLY a raw JSON object with a single key "emails", which is an array of strings. If no emails are found after a thorough search, return an empty array. Do not include any explanation or markdown.`;

            const response = await ai.models.generateContent({ model: "gemini-2.5-flash", contents: prompt, config: { tools: [{ googleSearch: {} }] } });
            const rawText = (response.text || '').trim();
            let foundEmails: string[] = [];

            try {
                let jsonText = rawText.replace(/^```json|```$/g, '').trim();
                const jsonResponse = JSON.parse(jsonText);
                const emailsFromServer = jsonResponse.emails;
                if (Array.isArray(emailsFromServer)) {
                    foundEmails = emailsFromServer.filter((email: any) => typeof email === 'string') as string[];
                }
            } catch (jsonError) {
                console.warn(`[handleScrapeEmails] JSON parsing failed for ${websiteUrl}. Falling back to regex. Error:`, jsonError);
                const emailRegex = /([a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z0-9._-]+)/gi;
                const matches = rawText.match(emailRegex);
                if (matches) { foundEmails = Array.from(new Set(matches)) as string[]; }
            }
            
            setBoardState((prev: any) => {
                const details = prev.scrapedBusinessDetails[businessIdentifier];
                const newEmailDetails = foundEmails.length > 0 
                    ? foundEmails.map((email, i) => ({ id: `${businessIdentifier}-emails-${i}`, value: email }))
                    : [{ id: `${businessIdentifier}-emails-none`, value: 'No public emails found.' }];
                return {
                    ...prev,
                    scrapedBusinessDetails: { ...prev.scrapedBusinessDetails, [businessIdentifier]: { ...details, emails: newEmailDetails } },
                    emailScrapeState: { ...prev.emailScrapeState, [businessIdentifier]: { loading: false, error: null } }
                };
            });
        } catch(e) {
             console.error(`[handleScrapeEmails] FORENSIC LOG: Email scrape failed for business: "${businessIdentifier}", URL: "${websiteUrl}". Error:`, e);
             setBoardState((prev: any) => ({ ...prev, emailScrapeState: { ...prev.emailScrapeState, [businessIdentifier]: { loading: false, error: "Email scrape failed." } } }));
        }
    };

    const handleBulkScrapeEmails = async (category: string) => {
        setBoardState((prev: any) => ({ ...prev, bulkEmailScrapeState: { ...prev.bulkEmailScrapeState, [category]: { loading: true, error: null } } }));
        
        const businessesInCategory = Object.entries(boardState.scrapedBusinessDetails)
            .filter(([id]) => id.startsWith(category + '-'))
            .map(([id, details]) => ({ id, details: details as BusinessDetails }));

        for (const { id, details } of businessesInCategory) {
            const websiteUrl = details.website[0]?.value;
            if(websiteUrl) {
                await handleScrapeEmails(id, websiteUrl);
            }
        }
        
        setBoardState((prev: any) => ({ ...prev, bulkEmailScrapeState: { ...prev.bulkEmailScrapeState, [category]: { loading: false, error: null } } }));
    };

    const handleToggleAllCategories = (open: boolean) => {
        setBoardState((prev: any) => {
            const newExpanded = new Set(open ? categories : []);
            return { ...prev, expandedCategories: newExpanded };
        });
        setIsCategoryToolkitOpen(false);
    };

    const handleGenerateGif = (businessDetails: BusinessDetails, category: string) => {
        // TEMPLATE: Replace with your GIF generation service URL
        const baseUrl = boardState.gifBaseUrl || 'https://[YOUR_GIF_SERVICE_URL]';
        const company = encodeURIComponent(businessDetails.name);
        const services = encodeURIComponent(category);
        const website = encodeURIComponent(businessDetails.website[0]?.value || '');
        const seed = encodeURIComponent(businessDetails.name);

        const gifUrl = `${baseUrl}/marketing.gif?count=6&random=true&seed=${seed}&company=${company}&services=${services}&url=${website}&font=tech&geometry=sharp`;

        setGifModalUrl(gifUrl);
    };

    if (loading) return <div className="loader">Loading...</div>;
    if (error) return <div className="error">{error}</div>;

    return (
        <div className="strategy-container">
             {isTemplateModalOpen && editingTemplateForCategory && (
                <EmailTemplateModal
                    category={editingTemplateForCategory}
                    template={boardState.emailTemplates[editingTemplateForCategory] || createDefaultTemplate(editingTemplateForCategory)}
                    onSave={handleSaveTemplate}
                    onClose={() => setIsTemplateModalOpen(false)}
                />
            )}
             {gifModalUrl && (
                <GifModal gifUrl={gifModalUrl} onClose={() => setGifModalUrl(null)} />
            )}
            <div className="controls-header-wrapper">
                <div className="controls-header">
                    <h1>Scraping Strategy Board</h1>
                </div>
            </div>
            <div className="strategy-card city-selector">
                <label htmlFor="city">Target City:</label>
                <input
                    id="city"
                    type="text"
                    className="search-input"
                    value={boardState.city}
                    onChange={(e) => setBoardState((prev: any) => ({ ...prev, city: e.target.value }))}
                />
            </div>
            <div className="strategy-grid-container">
                <table className="strategy-grid">
                    <thead>
                        <tr>
                            <th ref={toolkitRef} className="category-header">
                                <div className="category-header-toolkit">
                                    <span className="category-toolkit-trigger" onClick={() => setIsCategoryToolkitOpen(prev => !prev)}>
                                        Category Settings
                                        <span className={`accordion-arrow ${isCategoryToolkitOpen ? 'expanded' : ''}`}>&#9656;</span>
                                    </span>
                                    {isCategoryToolkitOpen && (
                                        <div className="category-toolkit-dropdown">
                                            <div className="toolkit-setting">
                                                <label htmlFor="gif-url">GIF Service URL:</label>
                                                <input 
                                                    id="gif-url"
                                                    type="text" 
                                                    value={boardState.gifBaseUrl}
                                                    onChange={(e) => setBoardState((prev: any) => ({...prev, gifBaseUrl: e.target.value}))}
                                                    onClick={(e) => e.stopPropagation()}
                                                />
                                            </div>
                                            <button onClick={() => handleToggleAllCategories(true)}>Open All Rows</button>
                                            <button onClick={() => handleToggleAllCategories(false)}>Close All Rows</button>
                                        </div>
                                    )}
                                </div>
                                <div className="sub-header">All business categories</div>
                            </th>
                            <th className="phase-1-text"><div>Phase 1</div><div className="sub-header">Market Analysis</div></th>
                            <th className="phase-2-text"><div>Phase 2</div><div className="sub-header">Initial Contact</div></th>
                            <th className="phase-3-text"><div>Phase 3</div><div className="sub-header">Interested / Follow-up</div></th>
                            <th className="phase-4-text"><div>Phase 4</div><div className="sub-header">Closed (Won/Lost)</div></th>
                        </tr>
                    </thead>
                    <tbody>
                        {categories.map(category => {
                            const currentPhase = boardState.categoryPhases[category];
                            const recon = boardState.reconData[category];
                            const scrape = boardState.scrapedResults[category];
                            const isCategoryExpanded = boardState.expandedCategories.has(category);

                            const businessIdentifiers = Object.keys(boardState.scrapedBusinessDetails).filter(id => id.startsWith(category + '-'));

                            return (
                                <Fragment key={category}>
                                    <tr>
                                        <th>
                                            <div className="category-header-content" onClick={() => handleCategoryToggle(category)}>
                                                <span><span className={`accordion-arrow ${isCategoryExpanded ? 'expanded' : ''}`}>&#9656;</span> {category}</span>
                                                <button title={boardState.emailTemplates[category] ? "Edit Email Template" : "Create Email Template"} className={`template-email-button ${boardState.emailTemplates[category] ? 'template-set' : ''}`} onClick={(e) => { e.stopPropagation(); handleOpenTemplateModal(category); }}>
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg>
                                                </button>
                                            </div>
                                        </th>
                                        {[1, 2, 3, 4].map(phase => (
                                            <td key={phase} className="phase-cell">
                                                <input
                                                    type="radio"
                                                    id={`${category}-phase-${phase}`}
                                                    name={`${category}-phase`}
                                                    className="bubble-input"
                                                    checked={currentPhase === phase}
                                                    onChange={() => handleCategoryPhaseChange(category, phase)}
                                                    disabled={phase !== 1}
                                                />
                                                <label htmlFor={`${category}-phase-${phase}`} className={`radio-bubble phase-${phase}`}></label>
                                            </td>
                                        ))}
                                    </tr>
                                    {isCategoryExpanded && (
                                        <tr className="accordion-content-row">
                                            <td colSpan={5} className="accordion-content-cell">
                                                <div className="accordion-content">
                                                    {recon?.loading && <p>Analyzing market...</p>}
                                                    {recon?.error && <p className="error">{recon.error}</p>}
                                                    {recon?.data && (
                                                        <div className="recon-results">
                                                            <h4>Market Size Analysis</h4>
                                                            <p><strong>Total Pages Found:</strong> {recon.data.totalPages}</p>
                                                            <p><strong>Results Per Page:</strong> {recon.data.resultsPerPage}</p>
                                                            <p className="recon-summary"><strong>Summary:</strong> {recon.data.summary}</p>
                                                            <div className="recon-actions">
                                                                <a href={recon.data.searchUrl} target="_blank" rel="noopener noreferrer" className="recon-search-link">View Live Search Results</a>
                                                                <button className="recon-detail-button" onClick={() => fetchScrapedResults(category)} disabled={scrape?.loading}>
                                                                    {scrape?.loading ? 'Scraping...' : 'Scrape'}
                                                                </button>
                                                                {scrape?.results?.length > 0 && (
                                                                     <button className="recon-detail-button" onClick={() => handleBulkScrapeEmails(category)} disabled={boardState.bulkEmailScrapeState[category]?.loading}>
                                                                        {boardState.bulkEmailScrapeState[category]?.loading ? 'Scraping Emails...' : 'Scrape All Emails?'}
                                                                    </button>
                                                                )}
                                                            </div>
                                                        </div>
                                                    )}
                                                </div>
                                            </td>
                                        </tr>
                                    )}
                                    {businessIdentifiers.map(businessId => {
                                        const businessDetails = boardState.scrapedBusinessDetails[businessId];
                                        if (!businessDetails) return null;
                                        const isBusinessExpanded = boardState.expandedBusinesses[category]?.has(businessId);
                                        const emailScrapeStatus = boardState.emailScrapeState[businessId];

                                        return (
                                            <Fragment key={businessId}>
                                                <tr className="scrape-result-row">
                                                    <th className="indented-cell business-name-cell">
                                                        <div className="business-name-wrapper" onClick={() => handleBusinessToggle(businessId, category)}>
                                                            <span className={`accordion-arrow ${isBusinessExpanded ? 'expanded' : ''}`}>&#9656;</span> {businessDetails.name}
                                                        </div>
                                                         <button className="gif-button" onClick={(e) => { e.stopPropagation(); handleGenerateGif(businessDetails, category); }} title="Generate Marketing GIF">GIF</button>
                                                    </th>
                                                    {[1, 2, 3, 4].map(phase => <td key={phase}><span className="static-bubble disabled"></span></td>)}
                                                </tr>
                                                {isBusinessExpanded && (
                                                    ['address', 'phone', 'website', 'emails'].map(method => (
                                                        businessDetails[method as ContactMethod].map((detail, index) => {
                                                            const isPlaceholder = detail.value.startsWith('SCRAPE_URL_PLACEHOLDER');
                                                            const currentContactPhase = boardState.contactDetailPhases[detail.id];
                                                            
                                                            if (isPlaceholder) {
                                                                return (
                                                                    <tr key={`${detail.id}-placeholder`} className="business-detail-sub-row">
                                                                        <td className="detail-info-cell">
                                                                            <div className="detail-content-wrapper">
                                                                                <span className="detail-label">Emails:</span>
                                                                                <button className="scrape-url-button" onClick={() => handleScrapeEmails(businessId, businessDetails.website[0]?.value)} disabled={emailScrapeStatus?.loading}>
                                                                                    {emailScrapeStatus?.loading ? 'Scraping...' : 'Scrape URL for Emails'}
                                                                                </button>
                                                                            </div>
                                                                        </td>
                                                                        <td colSpan={4}></td>
                                                                    </tr>
                                                                );
                                                            }

                                                            return (
                                                                <tr key={detail.id} className={`business-detail-sub-row ${currentContactPhase ? `detail-selected phase-${currentContactPhase}-text` : ''}`}>
                                                                    <td className="detail-info-cell">
                                                                        <div className="detail-content-wrapper">
                                                                            <span className="detail-label">{method.charAt(0).toUpperCase() + method.slice(1)}:</span>
                                                                            <input type="text" className="detail-input" value={detail.value} onChange={(e) => handleContactDetailValueChange(businessId, method as ContactMethod, detail.id, e.target.value)} />
                                                                            {index === businessDetails[method as ContactMethod].length - 1 && (
                                                                                 <button onClick={() => handleAddContactDetail(businessId, method as ContactMethod)} className="add-detail-button">+</button>
                                                                            )}
                                                                        </div>
                                                                    </td>
                                                                    {[1, 2, 3, 4].map(phase => (
                                                                        <td key={phase} className="phase-cell">
                                                                            {phase >= 2 && method === 'emails' && (
                                                                                <>
                                                                                 <input type="radio" id={`${detail.id}-phase-${phase}`} name={`${detail.id}-phase`} className="bubble-input" checked={currentContactPhase === phase} onChange={() => handleContactDetailPhaseChange(detail, phase, businessDetails, category)}/>
                                                                                 <label htmlFor={`${detail.id}-phase-${phase}`} className={`radio-bubble phase-${phase}`}></label>
                                                                                </>
                                                                            )}
                                                                        </td>
                                                                    ))}
                                                                </tr>
                                                            );
                                                        })
                                                    ))
                                                )}
                                            </Fragment>
                                        );
                                    })}
                                </Fragment>
                            );
                        })}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default StrategyBoard;
