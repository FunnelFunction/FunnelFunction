
import React, { useState, useEffect } from 'react';
import { GoogleGenAI } from '@google/genai';
import { Business, Source } from '../types';

const BusinessFinder = () => {
    const [category, setCategory] = useState('');
    const [city, setCity] = useState('Austin, TX');
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [results, setResults] = useState<Business[]>([]);
    const [sources, setSources] = useState<Source[]>([]);
    const [allCategories, setAllCategories] = useState<string[]>([]);
    const [filteredCategories, setFilteredCategories] = useState<string[]>([]);
    const [isDropdownVisible, setIsDropdownVisible] = useState(false);

    useEffect(() => {
        fetch('google-business-categories.json')
            .then(res => res.json())
            .then(data => setAllCategories(data))
            .catch(err => console.error("Failed to load categories", err));
    }, []);

    const handleCategoryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const value = e.target.value;
        setCategory(value);
        if (value) {
            setFilteredCategories(
                allCategories.filter(c => c.toLowerCase().includes(value.toLowerCase())).slice(0, 100)
            );
            setIsDropdownVisible(true);
        } else {
            setIsDropdownVisible(false);
        }
    };

    const handleCategorySelect = (selectedCategory: string) => {
        setCategory(selectedCategory);
        setIsDropdownVisible(false);
    };

    const handleSearch = async () => {
        if (!category || !city) {
            setError('Please enter both a business category and a city.');
            return;
        }
        setLoading(true);
        setError(null);
        setResults([]);
        setSources([]);

        try {
            const ai = new GoogleGenAI({ apiKey: import.meta.env.VITE_GEMINI_API_KEY });
            const prompt = `Find business information for "${category}" in "${city}". For each business, provide the name, address, phone number, and website. Respond with ONLY a raw JSON object (no markdown) with a key "businesses" which is an array of objects. Each object should have "name", "address", "phone", and "website" keys.`;
            const response = await ai.models.generateContent({
                model: "gemini-2.5-flash",
                contents: prompt,
                config: { tools: [{ googleSearch: {} }] }
            });

            const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
            if (groundingChunks) {
                const webSources = groundingChunks
                    .filter(chunk => chunk.web)
                    .map(chunk => ({ uri: chunk.web.uri, title: chunk.web.title || chunk.web.uri }));
                setSources(webSources);
            }

            let jsonText = response.text.trim().replace(/^```json|```$/g, '').trim();
            const data = JSON.parse(jsonText);
            setResults(data.businesses || []);
        } catch (e) {
            console.error("[handleSearch] FORENSIC LOG: Search failed for category:", category, "city:", city, "Error:", e);
            setError('An error occurred during the search. The AI may have returned an invalid format. Please try again.');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="container">
            <h1>AI Business Finder</h1>
            <p className="subtitle">Instantly find business leads with AI-powered search.</p>
            <div className="search-bar">
                <div className="category-search-container">
                    <input
                        type="text"
                        value={category}
                        onChange={handleCategoryChange}
                        onFocus={() => setIsDropdownVisible(true)}
                        onBlur={() => setTimeout(() => setIsDropdownVisible(false), 200)}
                        placeholder="e.g., Accountant, Plumber..."
                        className="search-input"
                    />
                    {isDropdownVisible && filteredCategories.length > 0 && (
                        <div className="category-dropdown">
                            {filteredCategories.map(cat => (
                                <div key={cat} className="category-dropdown-item" onClick={() => handleCategorySelect(cat)}>
                                    {cat}
                                </div>
                            ))}
                        </div>
                    )}
                </div>
                <input
                    type="text"
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    placeholder="City, State"
                    className="search-input"
                />
                <button onClick={handleSearch} disabled={loading} className="search-button">
                    {loading ? 'Searching...' : 'Find Businesses'}
                </button>
            </div>
            {error && <p className="error">{error}</p>}
            <div className="results-grid">
                {results.map((biz, index) => (
                    <div key={index} className="result-card">
                        <h3>{biz.name}</h3>
                        {biz.address && <p><strong>Address:</strong> {biz.address}</p>}
                        {biz.phone && <p><strong>Phone:</strong> <a href={`tel:${biz.phone}`}>{biz.phone}</a></p>}
                        {biz.website && <p><strong>Website:</strong> <a href={biz.website} target="_blank" rel="noopener noreferrer">{biz.website}</a></p>}
                    </div>
                ))}
            </div>
            {sources.length > 0 && (
                <div className="sources-container">
                    <h4>Sources</h4>
                    <ul className="sources-list">
                        {sources.map((source, index) => (
                            <li key={index} className="source-item">
                                <a href={source.uri} target="_blank" rel="noopener noreferrer">{source.title || source.uri}</a>
                            </li>
                        ))}
                    </ul>
                </div>
            )}
        </div>
    );
};

export default BusinessFinder;
