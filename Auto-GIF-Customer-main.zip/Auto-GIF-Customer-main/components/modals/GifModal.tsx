
import React from 'react';

const GifModal = ({ gifUrl, onClose }: { gifUrl: string; onClose: () => void }) => {
    return (
        <div className="modal-overlay gif-modal-overlay" onClick={onClose}>
            <div className="modal-content gif-modal-content" onClick={(e) => e.stopPropagation()}>
                <button className="gif-modal-close-button" onClick={onClose}>&times;</button>
                <img src={gifUrl} alt="Generated Marketing GIF" className="gif-modal-image" />
                <div className="gif-modal-url-container">
                    <label htmlFor="gif-url-display">Generated URL:</label>
                    <input id="gif-url-display" type="text" value={gifUrl} readOnly className="gif-modal-url-input" onClick={(e) => (e.target as HTMLInputElement).select()} />
                </div>
            </div>
        </div>
    );
};

export default GifModal;
