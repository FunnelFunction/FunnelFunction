
import React, { useState } from 'react';
import { ProfileData } from '../../types';

const ProfileModal = ({ profile, onSave, onClose }: { profile: ProfileData, onSave: (newProfile: ProfileData) => void, onClose: () => void }) => {
    const [localProfile, setLocalProfile] = useState(profile);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setLocalProfile(prev => ({ ...prev, [name]: value }));
    };

    const handleSave = () => {
        onSave(localProfile);
        onClose();
    };

    return (
        <div className="modal-overlay">
            <div className="modal-content">
                <h2>Your Profile</h2>
                <p>This information will be used in your email templates.</p>
                <div className="modal-form">
                    <label>Your Name:</label>
                    <input type="text" name="name" value={localProfile.name} onChange={handleChange} placeholder="e.g., John Doe" />
                    <label>Your Company:</label>
                    <input type="text" name="company" value={localProfile.company} onChange={handleChange} placeholder="e.g., Acme Inc." />
                    <label>Your Title:</label>
                    <input type="text" name="title" value={localProfile.title} onChange={handleChange} placeholder="e.g., Sales Director" />
                    <label>Your Email:</label>
                    <input type="email" name="email" value={localProfile.email} onChange={handleChange} placeholder="e.g., john.doe@acme.com" disabled />
                    <label>Your Phone:</label>
                    <input type="tel" name="phone" value={localProfile.phone} onChange={handleChange} placeholder="e.g., (555) 123-4567" />
                    <label>Your Business Description:</label>
                    <textarea name="businessDescription" value={localProfile.businessDescription} onChange={handleChange} rows={4} placeholder="Describe what your business does..."></textarea>
                </div>
                <div className="modal-actions">
                    <button onClick={onClose} className="modal-button secondary">Cancel</button>
                    <button onClick={handleSave} className="modal-button primary">Save Profile</button>
                </div>
            </div>
        </div>
    );
};

export default ProfileModal;
