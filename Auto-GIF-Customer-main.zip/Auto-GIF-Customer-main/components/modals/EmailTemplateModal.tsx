
import React, { useState } from 'react';

const EmailTemplateModal = ({ category, template, onSave, onClose }: { category: string, template: string, onSave: (category: string, newTemplate: string) => void, onClose: () => void }) => {
    const [localTemplate, setLocalTemplate] = useState(template);

    const handleSave = () => {
        onSave(category, localTemplate);
        onClose();
    };
    
    const adminPlaceholders = [
        { key: "{{admin_name}}", desc: "Your name" },
        { key: "{{admin_company}}", desc: "Your company name" },
        { key: "{{admin_title}}", desc: "Your job title" },
        { key: "{{admin_email}}", desc: "Your email address" },
        { key: "{{admin_phone}}", desc: "Your phone number" },
        { key: "{{admin_businessDescription}}", desc: "Your business summary" },
    ];
    
    const customerPlaceholders = [
        { key: "{{customer_name}}", desc: "The company's name" },
        { key: "{{customer_address}}", desc: "The company's primary address" },
        { key: "{{customer_phone}}", desc: "The company's primary phone" },
        { key: "{{customer_website}}", desc: "The company's website" },
        { key: "{{gif_url}}", desc: "Personalized GIF preview link" },
    ];

    return (
        <div className="modal-overlay">
            <div className="modal-content modal-large">
                <h2>Email Template for: <span className="modal-category-name">{category}</span></h2>
                <div className="template-editor-container">
                    <div className="template-editor-main">
                         <p>Compose your email template below. Use the placeholders on the right to automatically insert data.</p>
                        <textarea
                            value={localTemplate}
                            onChange={(e) => setLocalTemplate(e.target.value)}
                            rows={15}
                            placeholder={`Hi {{customer_name}},\n\nMy name is {{admin_name}}...`}
                        ></textarea>
                    </div>
                    <div className="template-editor-sidebar">
                        <h4>Placeholders</h4>
                        <p>Click to copy</p>
                        <h5>Your Info (Admin)</h5>
                        <ul className="placeholder-list">
                            {adminPlaceholders.map(p => (
                                <li key={p.key} className="placeholder-item" onClick={() => navigator.clipboard.writeText(p.key)} title="Click to copy">
                                    <span className="placeholder-key">{p.key}</span>
                                    <span className="placeholder-desc">{p.desc}</span>
                                </li>
                            ))}
                        </ul>
                         <h5>Lead Info (Customer)</h5>
                         <ul className="placeholder-list">
                            {customerPlaceholders.map(p => (
                                <li key={p.key} className="placeholder-item" onClick={() => navigator.clipboard.writeText(p.key)} title="Click to copy">
                                    <span className="placeholder-key">{p.key}</span>
                                    <span className="placeholder-desc">{p.desc}</span>
                                </li>
                            ))}
                        </ul>
                    </div>
                </div>
                <div className="modal-actions">
                    <button onClick={onClose} className="modal-button secondary">Cancel</button>
                    <button onClick={handleSave} className="modal-button primary">Save Template</button>
                </div>
            </div>
        </div>
    );
};

export default EmailTemplateModal;
