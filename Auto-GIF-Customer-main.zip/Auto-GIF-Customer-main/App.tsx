import React, { useState, useEffect } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase } from './supabase';
import { ProfileData, BoardState } from "./types";
import AuthComponent from './components/AuthComponent';
import ProfileModal from './components/modals/ProfileModal';
import BusinessFinder from './components/BusinessFinder';
import StrategyBoard from './components/StrategyBoard';

const defaultBoardState: BoardState = {
    city: 'Austin, TX',
    categoryPhases: {},
    reconData: {},
    scrapedResults: {},
    scrapedBusinessDetails: {},
    contactDetailPhases: {},
    emailTemplates: {},
    emailScrapeState: {},
    bulkEmailScrapeState: {},
    expandedCategories: new Set<string>(),
    expandedBusinesses: {},
    gifBaseUrl: 'https://render-dynamic-marketing-gif.onrender.com',
};

const App = () => {
    const [user, setUser] = useState<User | null>(null);
    const [session, setSession] = useState<Session | null>(null);
    const [authLoading, setAuthLoading] = useState(true);

    const [activeTab, setActiveTab] = useState('strategy');
    const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
    const [profileData, setProfileData] = useState<ProfileData>(() => {
        try {
            const savedProfile = localStorage.getItem('appProfileData');
            return savedProfile ? JSON.parse(savedProfile) : {
                name: '', company: '', title: '', email: '', phone: '', businessDescription: ''
            };
        } catch (e) {
            console.error("Failed to parse profile from localStorage", e);
            return { name: '', company: '', title: '', email: '', phone: '', businessDescription: '' };
        }
    });

    const [boardState, setBoardState] = useState(() => {
        try {
            const savedState = localStorage.getItem('strategyBoardState');
            if (savedState) {
                const parsed = JSON.parse(savedState);
                parsed.expandedCategories = new Set(parsed.expandedCategories || []);
                if(parsed.expandedBusinesses) {
                    Object.keys(parsed.expandedBusinesses).forEach(key => {
                        parsed.expandedBusinesses[key] = new Set(parsed.expandedBusinesses[key] || []);
                    })
                } else {
                    parsed.expandedBusinesses = {};
                }
                // Ensure defaults like gifBaseUrl exist if not in local storage
                return { ...defaultBoardState, ...parsed };
            }
            return defaultBoardState;
        } catch (e) {
            console.error("Failed to parse board state from localStorage", e);
            return defaultBoardState;
        }
    });

    useEffect(() => {
        // Get initial session
        supabase.auth.getSession().then(({ data: { session } }) => {
            setSession(session);
            setUser(session?.user ?? null);
            setAuthLoading(false);
        });

        // Listen for auth changes
        const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
            setSession(session);
            setUser(session?.user ?? null);
        });

        return () => subscription.unsubscribe();
    }, []);

    useEffect(() => {
        if (user) {
            setProfileData(prev => ({
                ...prev,
                name: user.user_metadata?.display_name || prev.name || '',
                email: user.email || prev.email || '',
            }));
        }
    }, [user]);

    useEffect(() => {
        try {
            localStorage.setItem('appProfileData', JSON.stringify(profileData));
        } catch (e) {
            console.error("Failed to save profile to localStorage", e);
        }
    }, [profileData]);

    useEffect(() => {
        try {
            const stateToSave: any = { ...boardState };
            stateToSave.expandedCategories = Array.from(stateToSave.expandedCategories);
            if(stateToSave.expandedBusinesses) {
                const businessesToSave: {[key:string]: string[]} = {};
                Object.keys(stateToSave.expandedBusinesses).forEach(key => {
                    businessesToSave[key] = Array.from(stateToSave.expandedBusinesses[key]);
                })
                stateToSave.expandedBusinesses = businessesToSave;
            }
            localStorage.setItem('strategyBoardState', JSON.stringify(stateToSave));
        } catch (e) {
            console.error("Failed to save board state to localStorage", e);
        }
    }, [boardState]);

    // Expose state for debugging
    (window as any)._app_state = { boardState, setBoardState };

    const handleSaveProfile = async (newProfile: ProfileData) => {
        setProfileData(newProfile);
        if (user && user.user_metadata?.display_name !== newProfile.name) {
            try {
                await supabase.auth.updateUser({
                    data: { display_name: newProfile.name }
                });
            } catch (e) {
                console.error("Failed to update auth profile name", e);
            }
        }
    };

    const handleSignOut = async () => {
        try {
            await supabase.auth.signOut();
        } catch (error) {
            console.error("Sign out error", error);
        }
    };

    if (authLoading) {
        return <div className="loader">Authenticating...</div>;
    }

    // Get avatar URL from user metadata
    const avatarUrl = user?.user_metadata?.avatar_url;
    const displayName = user?.user_metadata?.display_name || user?.email;

    return (
        <>
            {!user ? (
                <AuthComponent />
            ) : (
                <>
                    {isProfileModalOpen && (
                        <ProfileModal
                            profile={profileData}
                            onSave={handleSaveProfile}
                            onClose={() => setIsProfileModalOpen(false)}
                        />
                    )}
                    <header className="app-header">
                        <nav className="main-nav">
                            <button className={`nav-tab ${activeTab === 'strategy' ? 'active' : ''}`} onClick={() => setActiveTab('strategy')}>Strategy Board</button>
                            <button className={`nav-tab ${activeTab === 'finder' ? 'active' : ''}`} onClick={() => setActiveTab('finder')}>Business Search</button>
                        </nav>
                         <div className="header-user-info">
                            {avatarUrl && <div className="user-avatar" style={{backgroundImage: `url(${avatarUrl})`}}></div>}
                            <span>Welcome, {displayName} ({user?.email})</span>
                             <button className="profile-button" onClick={() => setIsProfileModalOpen(true)} title="Edit Your Profile">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                            </button>
                            <button className="sign-out-button" onClick={handleSignOut}>Sign Out</button>
                         </div>
                    </header>
                    <main>
                        {activeTab === 'finder' && <BusinessFinder />}
                        {activeTab === 'strategy' && <StrategyBoard appProfileData={profileData} boardState={boardState} setBoardState={setBoardState} providerToken={session?.provider_token} />}
                    </main>
                </>
            )}
        </>
    );
};

export default App;
